# Firebase Studio

This is a NextJS starter in Firebase Studio.1

To get started, take a look at src/app/page.tsx.
