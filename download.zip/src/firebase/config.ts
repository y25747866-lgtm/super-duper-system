export const firebaseConfig = {
  "projectId": "boss-os-85007592-9e993",
  "appId": "1:567549291917:web:4171324fdbd00bbb4561c4",
  "apiKey": "AIzaSyDupaPcKQPRHnkfSek6nX6vqamhS70YKQE",
  "authDomain": "boss-os-85007592-9e993.firebaseapp.com",
  "measurementId": "",
  "messagingSenderId": "567549291917"
};
