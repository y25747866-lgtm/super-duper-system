// src/firebase/admin.ts
import { initializeApp, getApps, getApp, type App } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';

const adminApp =
  getApps().find((app) => app.name === 'admin') ||
  initializeApp(
    {
      // credential,
      // databaseURL: `https://<DATABASE_NAME>.firebaseio.com`,
    },
    'admin'
  );

export function getFirebaseAdminApp() {
  return adminApp;
}

export function getAdminAuth() {
  return getAuth(adminApp);
}

export function getAdminFirestore() {
  return getFirestore(adminApp);
}
