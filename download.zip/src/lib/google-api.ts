// This is a global type, so we don't need to import it
// It comes from the <Script> tag in layout.tsx
declare const google: any;

export interface GoogleTokenResponse {
    access_token: string;
    expires_in: number;
    scope: string;
    token_type: string;
}

interface TokenClientConfig {
  client_id?: string;
  scope: string;
  callback: (tokenResponse: GoogleTokenResponse) => void;
  error_callback?: (error: any) => void;
}

interface TokenClient {
  requestAccessToken: (overrideConfig?: { scope?: string }) => void;
}


export function initTokenClient(config: TokenClientConfig): TokenClient {
    if (typeof window === 'undefined' || !window.google) {
        throw new Error('Google Identity Services library not loaded.');
    }
    // The client ID is loaded from the environment variables by the Google script
    // so we don't need to provide it here.
    return google.accounts.oauth2.initTokenClient(config);
}
