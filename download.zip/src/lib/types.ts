export type DigitalProduct = {
  id: string;
  userId: string;
  title: string;
  productType: string;
  createdAt: string;
  charterContent?: string;
  googleDriveFileId: string | null;
  imageUrl?: string;
  altText?: string;
};
