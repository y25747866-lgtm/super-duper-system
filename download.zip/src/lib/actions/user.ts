'use server';

import { getFirestore, doc, setDoc, serverTimestamp } from 'firebase-admin/firestore';
import { getFirebaseAdminApp } from '@/firebase/admin';

// Use a simpler interface for the user data from the client
interface UserData {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}

export async function createUserAction(user: UserData) {
  // Ensure the admin app is initialized
  getFirebaseAdminApp();
  const db = getFirestore();
  const userRef = doc(db, 'users', user.uid);
  
  // Use serverTimestamp for createdAt
  await setDoc(userRef, {
    name: user.displayName,
    email: user.email,
    photoURL: user.photoURL,
    createdAt: serverTimestamp(),
  }, { merge: true }); // Use merge: true to avoid overwriting existing data

  return { success: true };
}
