'use server';

import {
  generateCharterAndCover,
  type GenerateCharterAndCoverInput,
  type GenerateCharterAndCoverOutput,
} from '@/ai/flows/generate-charter-and-cover';
import { getAdminFirestore } from '@/firebase/admin';
import { getAuth } from 'firebase-admin/auth';
import type { DigitalProduct } from '@/lib/types';

export async function generateProductAction(
  input: GenerateCharterAndCoverInput & { userId: string }
): Promise<GenerateCharterAndCoverOutput & { productId: string }> {
  const { userId, ...charterInput } = input;
  const { charterContent, coverImageUrl, altText } = await generateCharterAndCover(charterInput);
  
  const db = getAdminFirestore();

  const productData = {
      userId,
      title: input.productName,
      productType: input.productType,
      charterContent,
      imageUrl: coverImageUrl,
      altText,
      googleDriveFileId: null,
      createdAt: new Date().toISOString(),
  };

  const productRef = await db.collection('users').doc(userId).collection('digitalProducts').add(productData);

  return {
    charterContent,
    coverImageUrl,
    altText,
    productId: productRef.id,
  };
}


export type SaveToGoogleDriveInput = {
  product: DigitalProduct;
  accessToken: string;
};

export async function saveToDriveAction(input: SaveToGoogleDriveInput): Promise<{ googleDriveFileId?: string; error?: string; }> {
    const { product, accessToken } = input;
    const db = getAdminFirestore();

    try {
        const userInfoResponse = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
            headers: { 'Authorization': `Bearer ${accessToken}` },
        });

        if (!userInfoResponse.ok) {
            throw new Error('Failed to fetch user info from Google.');
        }

        const userInfo = await userInfoResponse.json();
        const userId = userInfo.sub;

        if (!userId || userId !== product.userId) {
            return { error: 'User not authenticated or does not own this product.' };
        }
        
        const docResponse = await fetch('https://docs.googleapis.com/v1/documents', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ title: product.title }),
        });

        if (!docResponse.ok) {
            const errorBody = await docResponse.json();
            throw new Error(`Failed to create document: ${errorBody.error.message}`);
        }

        const doc = await docResponse.json();
        const documentId = doc.documentId;

        const updateResponse = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                requests: [{
                    insertText: {
                        location: { index: 1 },
                        text: product.charterContent || '',
                    },
                }],
            }),
        });

        if (!updateResponse.ok) {
             const errorBody = await updateResponse.json();
             throw new Error(`Failed to update document content: ${errorBody.error.message}`);
        }

        const productRef = db.collection('users').doc(userId).collection('digitalProducts').doc(product.id);
        await productRef.update({ googleDriveFileId: documentId });

        return { googleDriveFileId: documentId };

    } catch (error: any) {
        console.error('Error saving to Google Drive:', error);
        return { error: error.message || 'An unknown error occurred.' };
    }
}