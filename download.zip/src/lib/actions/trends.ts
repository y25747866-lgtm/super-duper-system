'use server';

import {
  discoverTrendingProducts,
  type DiscoverTrendingProductsInput,
  type DiscoverTrendingProductsOutput,
} from '@/ai/flows/discover-trending-digital-products';

export async function discoverTrendsAction(
  input: DiscoverTrendingProductsInput
): Promise<DiscoverTrendingProductsOutput> {
  return await discoverTrendingProducts(input);
}
