'use server';

import {
  generateUVZProductIdeas,
  type GenerateUVZProductIdeasInput,
  type GenerateUVZProductIdeasOutput,
} from '@/ai/flows/generate-uvz-product-ideas';

export async function generateUVZAction(
  input: GenerateUVZProductIdeasInput
): Promise<GenerateUVZProductIdeasOutput> {
  return await generateUVZProductIdeas(input);
}
