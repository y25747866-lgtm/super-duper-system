

import Image from 'next/image';
import Link from 'next/link';
import {
  ArrowRight,
  Bot,
  FileText,
  Lightbulb,
  Star,
  TrendingUp,
} from 'lucide-react';

import { cn } from '@/lib/utils';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { Button, buttonVariants } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Icons } from '@/components/icons';
import { AuthButtons } from '@/components/auth-buttons';

const features = [
  {
    icon: <Lightbulb className="h-8 w-8 text-primary" />,
    title: 'UVZ Calculator',
    description:
      "AI analyzes your skills and market gaps to find your unique value zone.",
  },
  {
    icon: <FileText className="h-8 w-8 text-primary" />,
    title: 'Product Charter Generator',
    description:
      'Create detailed blueprints for courses, e-books, and more in minutes.',
  },
  {
    icon: <TrendingUp className="h-8 w-8 text-primary" />,
    title: 'AI Trends Search',
    description:
      'Discover trending digital product ideas for 2025 to stay ahead of the curve.',
  },
  {
    icon: <Bot className="h-8 w-8 text-primary" />,
    title: 'AI-Powered Content',
    description:
      'Generate high-quality content, from outlines to full drafts, with AI assistance.',
  },
];

const testimonials = PlaceHolderImages.filter(img => img.id.includes('testimonial'));

export default function LandingPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="container z-40 bg-background/80 backdrop-blur-sm fixed top-0 left-0 right-0">
        <div className="flex h-20 items-center justify-between py-6">
          <Link href="/" className="flex items-center gap-2">
            <Icons.logo className="h-8 w-8 text-primary" />
            <span className="font-bold font-headline">Boss OS</span>
          </Link>
          <nav className='flex items-center gap-4'>
            <AuthButtons />
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="space-y-6 pb-8 pt-24 md:pb-12 md:pt-28 lg:py-40">
          <div className="container flex max-w-[64rem] flex-col items-center gap-4 text-center">
            <h1 className="font-headline text-3xl font-extrabold sm:text-5xl md:text-6xl lg:text-7xl">
              Command Your Empire
            </h1>
            <p className="max-w-[42rem] leading-normal text-muted-foreground sm:text-xl sm:leading-8">
              Build & Launch Digital Products with Boss OS AI. The ultimate
              platform for creators and entrepreneurs to monetize their
              knowledge.
            </p>
            <div className="space-x-4">
               <AuthButtons largeButton />
            </div>
          </div>
        </section>

        <section
          id="features"
          className="container space-y-8 py-8 md:py-12 lg:py-24"
        >
          <div className="mx-auto flex max-w-[58rem] flex-col items-center space-y-4 text-center">
            <h2 className="font-headline text-3xl font-bold leading-[1.1] sm:text-3xl md:text-5xl">
              Features
            </h2>
            <p className="max-w-[85%] leading-normal text-muted-foreground sm:text-lg sm:leading-7">
              Boss OS provides all the tools you need to turn your expertise
              into a digital empire.
            </p>
          </div>
          <div className="mx-auto grid justify-center gap-4 sm:grid-cols-2 md:max-w-[64rem] md:grid-cols-4">
            {features.map((feature) => (
              <Card key={feature.title} className="text-center bg-card/50">
                <CardHeader>
                  <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                    {feature.icon}
                  </div>
                </CardHeader>
                <CardContent className="space-y-2">
                  <h3 className="font-bold font-headline">{feature.title}</h3>
                  <p className="text-sm text-muted-foreground">
                    {feature.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section id="demo" className="container py-8 md:py-12 lg:py-24">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center space-y-4 text-center">
            <h2 className="font-headline text-3xl font-bold leading-[1.1] sm:text-3xl md:text-5xl">
              See It In Action
            </h2>
            <p className="max-w-[85%] leading-normal text-muted-foreground sm:text-lg sm:leading-7">
              Watch how easy it is to create a digital product from scratch in under 5 minutes.
            </p>
            <div className="relative aspect-video w-full max-w-4xl overflow-hidden rounded-lg border">
              <Image
                src="https://picsum.photos/seed/laptop-creator/1280/720"
                alt="A person sitting at a laptop creating a digital product"
                fill
                className="object-cover"
                data-ai-hint="laptop creator"
              />
            </div>
          </div>
        </section>

        <section
          id="testimonials"
          className="container space-y-8 py-8 md:py-12 lg:py-24"
        >
          <div className="mx-auto flex max-w-[58rem] flex-col items-center space-y-4 text-center">
            <h2 className="font-headline text-3xl font-bold leading-[1.1] sm:text-3xl md:text-5xl">
              Loved by Creators
            </h2>
          </div>
          <Carousel
            opts={{
              align: 'start',
            }}
            className="w-full max-w-4xl mx-auto"
          >
            <CarouselContent>
              {testimonials.map((testimonial, index) => (
                <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/3">
                  <div className="p-1">
                    <Card className="bg-card/50">
                      <CardContent className="flex flex-col items-start gap-4 p-6">
                        <div className="flex gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star key={i} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
                          ))}
                        </div>
                        <p className="text-left text-sm">
                          &quot;Boss OS transformed my side hustle. I created and launched three e-books in a month! The AI tools are pure magic.&quot;
                        </p>
                        <div className="flex items-center gap-3">
                            <Avatar>
                                <AvatarImage src={testimonial.imageUrl} alt={testimonial.description} data-ai-hint={testimonial.imageHint}/>
                                <AvatarFallback>CN</AvatarFallback>
                            </Avatar>
                            <div>
                                <p className="font-semibold text-sm">Creator Name</p>
                                <p className="text-xs text-muted-foreground">Digital Entrepreneur</p>
                            </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious />
            <CarouselNext />
          </Carousel>
        </section>

        <section id="cta" className="container py-8 md:py-12 lg:py-24">
          <div className="mx-auto flex max-w-[58rem] flex-col items-center space-y-4 text-center">
            <h2 className="font-headline text-3xl font-bold leading-[1.1] sm:text-3xl md:text-5xl">
              Start Building Your Boss Empire
            </h2>
            <p className="max-w-[85%] leading-normal text-muted-foreground sm:text-lg sm:leading-7">
              Join thousands of creators turning their passion into profit. Get started for free today. No credit card required.
            </p>
            <AuthButtons largeButton />
          </div>
        </section>
      </main>
      <footer className="py-6 md:px-8 md:py-0">
          <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
            <p className="text-center text-sm leading-loose text-muted-foreground md:text-left">
              Built by{' '}
              <a
                href="#"
                target="_blank"
                rel="noreferrer"
                className="font-medium underline underline-offset-4"
              >
                Boss OS
              </a>
              . The source code is available on{' '}
              <a
                href="#"
                target="_blank"
                rel="noreferrer"
                className="font-medium underline underline-offset-4"
              >
                GitHub
              </a>
              .
            </p>
          </div>
        </footer>
    </div>
  );
}
