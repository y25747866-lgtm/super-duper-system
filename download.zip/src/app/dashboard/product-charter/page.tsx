
'use client';

import React, { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useForm, type SubmitHandler } from 'react-hook-form';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  type GenerateCharterAndCoverInput,
  type GenerateCharterAndCoverOutput,
} from '@/ai/flows/generate-charter-and-cover';
import { generateProductAction } from '@/lib/actions/product';
import { useToast } from '@/hooks/use-toast';
import { Bot, FileText, Loader2, Save } from 'lucide-react';
import { useFirebase } from '@/firebase';

type Inputs = GenerateCharterAndCoverInput;

function ProductCharterForm({ productNameFromQuery }: { productNameFromQuery?: string | null }) {
  const { toast } = useToast();
  const { user } = useFirebase();
  const router = useRouter();
  const [isGeneratingBlueprint, setIsGeneratingBlueprint] = useState(false);
  

  const {
    register,
    handleSubmit,
    setValue,
    formState: { errors },
    watch,
  } = useForm<Inputs>({
    defaultValues: {
      productName: productNameFromQuery || '',
      productType: 'ebook',
    },
  });

  useEffect(() => {
    if (productNameFromQuery) {
      setValue('productName', productNameFromQuery);
    }
  }, [productNameFromQuery, setValue]);

  const onBlueprintSubmit: SubmitHandler<Inputs> = async data => {
    if (!user) {
      toast({
        variant: 'destructive',
        title: 'Sign-in Required',
        description: 'Please sign in to generate a product.',
      });
      return;
    }
    setIsGeneratingBlueprint(true);
    
    try {
      await generateProductAction({ ...data, userId: user.uid });
      toast({
        title: 'Product Generated!',
        description: 'Your new product is available on the "My Products" page.',
      });
      router.push('/dashboard/my-products');
    } catch (error: any) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Error Generating Blueprint',
        description:
          error.message || 'An unexpected error occurred. Please try again.',
      });
    } finally {
      setIsGeneratingBlueprint(false);
    }
  };

  return (
     <Card>
          <CardHeader>
            <CardTitle className="font-headline">1. Enter Product Details</CardTitle>
            <CardDescription>
              Provide a name and type for your new digital product.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form
              onSubmit={handleSubmit(onBlueprintSubmit)}
              className="space-y-6"
            >
              <div>
                <Label htmlFor="productName">Product Name</Label>
                <Input
                  id="productName"
                  placeholder="e.g., 'The Art of Astrology'"
                  {...register('productName', { required: true })}
                />
                {errors.productName && (
                  <p className="text-sm text-destructive mt-1">
                    Product name is required.
                  </p>
                )}
              </div>
              <div>
                <Label htmlFor="productType">Product Type</Label>
                <Select
                  value={watch('productType')}
                  onValueChange={value =>
                    setValue('productType', value as 'ebook' | 'course')
                  }
                >
                  <SelectTrigger id="productType">
                    <SelectValue placeholder="Select a product type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ebook">E-Book</SelectItem>
                    <SelectItem value="course">Course</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button
                type="submit"
                disabled={isGeneratingBlueprint}
                className="w-full"
              >
                {isGeneratingBlueprint ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <FileText className="mr-2 h-4 w-4" />
                )}
                Generate Product & Go to My Products
              </Button>
            </form>
          </CardContent>
        </Card>
  );
}

export default function ProductCharterPage({
  searchParams,
}: {
  searchParams?: { [key: string]: string | string[] | undefined };
}) {
  const productName = searchParams?.productName as string | undefined;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">
          Product Generator
        </h1>
        <p className="text-muted-foreground">
          Generate a complete blueprint and cover for your next digital product.
        </p>
      </div>
       <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
        <div className="md:col-span-1 space-y-8">
          <ProductCharterForm productNameFromQuery={productName} />
        </div>
        <div className="md:col-span-2">
            <Card className="h-full min-h-[500px]">
                 <CardHeader>
                    <CardTitle className="font-headline">2. Review &amp; Manage</CardTitle>
                    <CardDescription>
                        After generation, your product will appear on the "My Products" page where you can review, edit, and save it to Google Drive.
                    </CardDescription>
                 </CardHeader>
                 <CardContent>
                     <div className="flex flex-col items-center justify-center h-64 gap-4 text-center border-2 border-dashed rounded-lg">
                        <Bot className="h-16 w-16 text-muted-foreground/50" />
                        <p className="text-muted-foreground max-w-sm">
                           The AI will generate the blueprint, a cover image, and save it to your product list.
                        </p>
                    </div>
                 </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
}
