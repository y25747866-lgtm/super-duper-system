'use client';

import { useState } from 'react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import Link from 'next/link';
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  type DiscoverTrendingProductsInput,
  type DiscoverTrendingProductsOutput,
} from '@/ai/flows/discover-trending-digital-products';
import { discoverTrendsAction } from '@/lib/actions/trends';
import { useToast } from '@/hooks/use-toast';
import { Bot, FilePlus, Loader2, Search, Sparkles } from 'lucide-react';

type Inputs = DiscoverTrendingProductsInput;

export default function TrendsPage() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<DiscoverTrendingProductsOutput | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<Inputs>();

  const onSubmit: SubmitHandler<Inputs> = async (data) => {
    setIsLoading(true);
    setResult(null);
    try {
      const response = await discoverTrendsAction(data);
      setResult(response);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error Discovering Trends',
        description: 'An unexpected error occurred. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">
          AI Training Digital Product Search
        </h1>
        <p className="text-muted-foreground">
          Discover trending digital products for 2025.
        </p>
      </div>

      <Card>
        <CardContent className="pt-6">
          <form
            onSubmit={handleSubmit(onSubmit)}
            className="flex flex-col sm:flex-row gap-2"
          >
            <Input
              id="query"
              placeholder="e.g., 'AI marketing courses' or 'SEO eBooks'"
              {...register('query', { required: true })}
              className="flex-grow"
            />
            <Button type="submit" disabled={isLoading} className="w-full sm:w-auto">
              {isLoading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Search className="mr-2 h-4 w-4" />
              )}
              Search Trends
            </Button>
          </form>
          {errors.query && (
            <p className="text-sm text-destructive mt-2">This field is required.</p>
          )}
        </CardContent>
      </Card>

      {isLoading && (
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <Bot className="h-16 w-16 text-primary animate-pulse" />
          <p className="text-muted-foreground">
            Searching for the next big thing...
          </p>
        </div>
      )}

      {result && (
        <div className="space-y-4">
          <h2 className="text-2xl font-bold font-headline">
            Trending Product Ideas
          </h2>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {result.products.map((product, index) => (
              <Card
                key={index}
                className="flex flex-col"
              >
                <CardHeader>
                  <CardTitle className="font-headline flex items-start gap-2">
                    <Sparkles className="h-5 w-5 text-primary flex-shrink-0 mt-1" />
                    <span>{product.title}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="flex-grow flex flex-col">
                  <p className="text-sm text-muted-foreground mb-4 flex-grow">
                    {product.description}
                  </p>
                  <Card
                    className="mt-auto bg-secondary/50"
                  >
                    <CardHeader className="p-4">
                       <CardTitle className="text-sm font-bold">Market Analysis (2025)</CardTitle>
                    </CardHeader>
                    <CardContent className="p-4 pt-0 text-xs text-muted-foreground">
                      {product.marketAnalysis}
                    </CardContent>
                  </Card>
                </CardContent>
                 <CardFooter>
                    <Button asChild className="w-full">
                      <Link href={`/dashboard/product-charter?productName=${encodeURIComponent(product.title)}`}>
                        <FilePlus className="mr-2 h-4 w-4" />
                        Create Product from this Idea
                      </Link>
                    </Button>
                  </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
