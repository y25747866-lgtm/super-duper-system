'use client';

import { useState } from 'react';
import { useForm, type SubmitHandler } from 'react-hook-form';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  type GenerateUVZProductIdeasInput,
  type GenerateUVZProductIdeasOutput,
} from '@/ai/flows/generate-uvz-product-ideas';
import { generateUVZAction } from '@/lib/actions/uvz';
import { useToast } from '@/hooks/use-toast';
import { Bot, Lightbulb, Loader2, Percent, Sparkles } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

type Inputs = GenerateUVZProductIdeasInput;

export default function UVZCalculatorPage() {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<GenerateUVZProductIdeasOutput | null>(
    null
  );

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<Inputs>();

  const onSubmit: SubmitHandler<Inputs> = async (data) => {
    setIsLoading(true);
    setResult(null);
    try {
      const response = await generateUVZAction(data);
      setResult(response);
    } catch (error) {
      toast({
        variant: 'destructive',
        title: 'Error Generating Ideas',
        description: 'An unexpected error occurred. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">
          Unique Value Zone (UVZ) Calculator
        </h1>
        <p className="text-muted-foreground">
          Discover product ideas at the intersection of your skills, audience
          needs, and market gaps.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="font-headline">Your Input</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
                <div>
                  <Label htmlFor="skills">Your Skills</Label>
                  <Textarea
                    id="skills"
                    placeholder="e.g., Astrology, Graphic Design, Copywriting"
                    {...register('skills', { required: true })}
                  />
                  {errors.skills && (
                    <p className="text-sm text-destructive">
                      Skills are required.
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="painPoints">Audience Pain Points</Label>
                  <Textarea
                    id="painPoints"
                    placeholder="e.g., Feeling lost in life, struggling with marketing"
                    {...register('painPoints', { required: true })}
                  />
                   {errors.painPoints && (
                    <p className="text-sm text-destructive">
                      Pain points are required.
                    </p>
                  )}
                </div>
                <div>
                  <Label htmlFor="marketGaps">Market Gaps</Label>
                  <Textarea
                    id="marketGaps"
                    placeholder="e.g., Lack of beginner-friendly guides, no affordable design templates"
                    {...register('marketGaps', { required: true })}
                  />
                   {errors.marketGaps && (
                    <p className="text-sm text-destructive">
                      Market gaps are required.
                    </p>
                  )}
                </div>
                <Button type="submit" disabled={isLoading} className="w-full">
                  {isLoading ? (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  ) : (
                    <Lightbulb className="mr-2 h-4 w-4" />
                  )}
                  Find My UVZ
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
        <div className="md:col-span-2">
            <Card className="h-full min-h-[500px]">
                <CardHeader>
                    <CardTitle className="font-headline">AI-Generated Product Ideas</CardTitle>
                    <CardDescription>Your unique product opportunities will appear here.</CardDescription>
                </CardHeader>
                <CardContent>
                {isLoading && (
                    <div className="flex flex-col items-center justify-center h-64 gap-4">
                        <Bot className="h-16 w-16 text-primary animate-pulse" />
                        <p className="text-muted-foreground">Calculating your Unique Value Zone...</p>
                    </div>
                )}
                {result && result.productIdeas.length > 0 && (
                  <div className="space-y-4">
                    {result.productIdeas.map((idea, index) => (
                      <Card key={index} className="bg-secondary/50">
                        <CardHeader>
                            <CardTitle className="flex justify-between items-start gap-4">
                                <span className="font-headline flex items-center gap-2"><Sparkles className="h-5 w-5 text-primary" />{idea.productName}</span>
                                <div className="flex items-center gap-2 text-lg font-bold text-primary">
                                    {idea.matchPercentage}<Percent className="h-5 w-5" />
                                </div>
                            </CardTitle>
                            <Progress value={idea.matchPercentage} className="h-2" />
                        </CardHeader>
                        <CardContent>
                            <p className="text-sm text-muted-foreground">{idea.relevanceAnalysis}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
                 {!isLoading && !result && (
                  <div className="flex flex-col items-center justify-center h-64 gap-4 text-center border-2 border-dashed rounded-lg">
                      <Lightbulb className="h-16 w-16 text-muted-foreground/50" />
                      <p className="text-muted-foreground">Enter your details and let our AI find your next big product idea.</p>
                  </div>
                )}
                </CardContent>
            </Card>
        </div>
      </div>
    </div>
  );
}
