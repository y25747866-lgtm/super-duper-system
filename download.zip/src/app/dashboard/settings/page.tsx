'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Icons } from '@/components/icons';
import { useToast } from '@/hooks/use-toast';
import { initTokenClient, type GoogleTokenResponse } from '@/lib/google-api';
import { CheckCircle, ExternalLink } from 'lucide-react';

// We'll use a simple local state to track connection for this example.
// In a real app, you'd fetch this from your backend.
let isConnected = false;

export default function SettingsPage() {
  const { toast } = useToast();
  const [connectionStatus, setConnectionStatus] = React.useState(isConnected);

  const handleConnect = async () => {
    try {
      const tokenClient = initTokenClient({
        scope: 'https://www.googleapis.com/auth/drive.file',
        callback: (tokenResponse: GoogleTokenResponse) => {
          if (tokenResponse && tokenResponse.access_token) {
            toast({
              title: 'Successfully Connected!',
              description: 'Your Google Drive is now connected.',
            });
            isConnected = true;
            setConnectionStatus(true);
            // In a real app, you would send this token to your backend to store it securely.
          }
        },
        error_callback: (error: any) => {
            toast({
                variant: 'destructive',
                title: 'Connection Failed',
                description: error?.details || 'Could not connect to Google Drive. Please try again.',
            });
        }
      });
      tokenClient.requestAccessToken();
    } catch (error: any) {
      console.error('Error initializing Google token client:', error);
      toast({
        variant: 'destructive',
        title: 'Google Auth Error',
        description: 'Could not initialize Google authentication. Please try again.',
      });
    }
  };

  const handleDisconnect = () => {
    // In a real app, you would also revoke the token on the backend.
     toast({
        title: 'Disconnected',
        description: 'Your Google Drive has been disconnected.',
    });
    isConnected = false;
    setConnectionStatus(false);
  }

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">Settings</h1>
        <p className="text-muted-foreground">
          Manage your account settings and integrations.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Integrations</CardTitle>
          <CardDescription>
            Connect your Boss OS account to other services.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between p-4 border rounded-lg">
            <div className='flex items-center gap-4'>
                <Icons.google className="h-6 w-6" />
                <div>
                    <h3 className="font-semibold">Google Drive</h3>
                    <p className="text-sm text-muted-foreground">
                        Save your generated product blueprints directly to your drive.
                    </p>
                </div>
            </div>
            {connectionStatus ? (
                 <div className='flex items-center gap-4'>
                    <span className='flex items-center gap-2 text-sm text-green-500'><CheckCircle className='h-4 w-4'/> Connected</span>
                    <Button variant="outline" onClick={handleDisconnect}>Disconnect</Button>
                </div>
            ) : (
                <Button onClick={handleConnect}>
                    <ExternalLink className="mr-2 h-4 w-4" /> Connect
                </Button>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
