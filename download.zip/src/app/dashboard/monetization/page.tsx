
'use client';

import { CheckCircle, CircleDollarSign, Loader2 } from 'lucide-react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useTransition } from 'react';
import { useToast } from '@/hooks/use-toast';

const freePlanFeatures = [
  'Generate 3 Product Blueprints',
  'Run 5 UVZ Calculations',
  'Limited AI Trend Searches',
  'Community Support',
];

const bossModeFeatures = [
  'Unlimited Product Blueprints',
  'Unlimited UVZ Calculations',
  'Unlimited AI Trend Searches',
  'Generate E-books & Courses',
  'Priority Support',
];

export default function MonetizationPage() {
  const [isPending, startTransition] = useTransition();
  const { toast } = useToast();

  const handleUpgrade = async () => {
    toast({
        variant: 'default',
        title: 'Coming Soon!',
        description: 'Monetization features are under construction.',
    });
  };

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">Monetization Hub</h1>
        <p className="text-muted-foreground">
          Choose a plan that fits your empire-building needs.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
        <Card>
          <CardHeader>
            <CardTitle className="font-headline">Free Plan</CardTitle>
            <CardDescription>
              For aspiring bosses getting started.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-4xl font-bold font-headline">$0<span className="text-sm font-normal text-muted-foreground">/month</span></p>
            <ul className="space-y-2">
              {freePlanFeatures.map((feature, i) => (
                <li key={i} className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-green-500" />
                  {feature}
                </li>
              ))}
            </ul>
          </CardContent>
          <CardFooter>
            <Button variant="outline" disabled className="w-full">
              Your Current Plan
            </Button>
          </CardFooter>
        </Card>

        <Card className="border-primary shadow-lg shadow-primary/10">
           <CardHeader>
            <CardTitle className="font-headline flex items-center justify-between">
                <span>Boss Mode</span>
                <span className="text-xs font-normal bg-primary text-primary-foreground px-2 py-1 rounded-full">Recommended</span>
            </CardTitle>
            <CardDescription>
              For serious entrepreneurs scaling their empire.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
          <p className="text-4xl font-bold font-headline">$29<span className="text-sm font-normal text-muted-foreground">/month</span></p>
            <ul className="space-y-2">
              {bossModeFeatures.map((feature, i) => (
                <li key={i} className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-primary" />
                  {feature}
                </li>
              ))}
            </ul>
          </CardContent>
          <CardFooter>
            <Button onClick={handleUpgrade} disabled={isPending} className="w-full">
              {isPending ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <CircleDollarSign className="mr-2 h-4 w-4" />
              )}
              Upgrade to Boss Mode
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
}
