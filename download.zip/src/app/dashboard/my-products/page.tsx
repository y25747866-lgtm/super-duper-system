'use client';

import { useMemo, useState, useEffect } from 'react';
import Link from 'next/link';
import { collection, getDocs, limit, query } from 'firebase/firestore';
import { useCollection, useFirebase, useMemoFirebase } from '@/firebase';
import { useToast } from '@/hooks/use-toast';
import { saveToDriveAction } from '@/lib/actions/product';
import { initTokenClient, type GoogleTokenResponse } from '@/lib/google-api';

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Book, FileText, Loader2, Image as ImageIcon, Settings, Save, CheckCircle } from 'lucide-react';
import Image from 'next/image';
import type { DigitalProduct } from '@/lib/types';


function ProductRow({ product }: { product: DigitalProduct }) {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);
  
  const handleSave = async () => {
    setIsSaving(true);
    try {
      const tokenClient = initTokenClient({
        scope: 'https://www.googleapis.com/auth/drive.file',
        callback: async (tokenResponse: GoogleTokenResponse) => {
          if (tokenResponse && tokenResponse.access_token) {
            try {
              const result = await saveToDriveAction({
                product,
                accessToken: tokenResponse.access_token,
              });

              if (result.googleDriveFileId) {
                 toast({
                  title: 'Saved to Google Drive!',
                  description: 'Your product has been saved successfully.',
                });
                // Note: The UI will update automatically due to Firestore real-time updates
              } else {
                throw new Error(result.error || 'Failed to save to Google Drive.');
              }
            } catch (error: any) {
               toast({
                variant: 'destructive',
                title: 'Error Saving to Drive',
                description: error.message || 'An unexpected error occurred.',
              });
            } finally {
              setIsSaving(false);
            }
          }
        },
      });
      tokenClient.requestAccessToken();
    } catch (error: any) {
        toast({
            variant: 'destructive',
            title: 'Google Auth Error',
            description: 'Could not initialize Google authentication. Please try again.',
        });
        setIsSaving(false);
    }
  };
  
  return (
    <TableRow>
      <TableCell className="font-medium flex items-center gap-4">
        {product.imageUrl ? (
          <Image
            src={product.imageUrl}
            alt={product.altText || ''}
            width={40}
            height={56}
            className="rounded-md aspect-[9/16] object-cover"
          />
        ) : (
            <div className="w-10 h-[56px] bg-secondary rounded-md flex items-center justify-center">
                <ImageIcon className='h-4 w-4 text-muted-foreground' />
            </div>
        )}
        <span>{product.title}</span>
      </TableCell>
      <TableCell>
        <Badge variant="outline" className="capitalize">
          <Book className="mr-1.5 h-3 w-3" />
          {product.productType}
        </Badge>
      </TableCell>
      <TableCell>
        {new Date(product.createdAt).toLocaleDateString()}
      </TableCell>
      <TableCell className="text-right">
        {product.googleDriveFileId ? (
           <Button asChild variant="ghost" size="sm">
            <a
              href={`https://docs.google.com/document/d/${product.googleDriveFileId}`}
              target="_blank"
              rel="noopener noreferrer"
            >
              View in Google Drive
            </a>
          </Button>
        ) : (
          <Button onClick={handleSave} disabled={isSaving} size="sm">
            {isSaving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Save className="mr-2 h-4 w-4" />}
            Save to Google Drive
          </Button>
        )}
      </TableCell>
    </TableRow>
  );
}


export default function MyProductsPage() {
  const { firestore, user } = useFirebase();
  const [isGoogleConnected, setIsGoogleConnected] = useState(false);
  const [isConnectionCheckLoading, setIsConnectionCheckLoading] = useState(true);

  const productsCollection = useMemoFirebase(
    () => (firestore && user ? collection(firestore, 'users', user.uid, 'digitalProducts') : null),
    [firestore, user]
  );
  
  const { data: products, isLoading: isLoadingProducts } = useCollection<DigitalProduct>(productsCollection);

  useEffect(() => {
    async function checkGoogleConnection() {
      if (!firestore || !user) {
        setIsConnectionCheckLoading(false);
        return;
      }
      setIsConnectionCheckLoading(true);
      // A simple way to check for connection is to see if any product has been saved to Drive.
      // A more robust solution might involve a dedicated 'connections' document in Firestore.
      const q = query(collection(firestore, 'users', user.uid, 'digitalProducts'), limit(1));
      const querySnapshot = await getDocs(q);
      const hasConnectedProduct = querySnapshot.docs.some(doc => !!doc.data().googleDriveFileId);
      setIsGoogleConnected(hasConnectedProduct);
      setIsConnectionCheckLoading(false);
    }
    checkGoogleConnection();
  }, [firestore, user, products]);


  const sortedProducts = useMemo(() => {
    if (!products) return [];
    return [...products].sort((a, b) => {
        const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
        const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
        return dateB - dateA;
    });
  }, [products]);
  
  const isLoading = isLoadingProducts || isConnectionCheckLoading;

  const hasProducts = sortedProducts && sortedProducts.length > 0;

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">My Products</h1>
        <p className="text-muted-foreground">
          A list of your generated digital products.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Digital Assets</CardTitle>
          <CardDescription>
            View your generated e-books and courses. Save them to Google Drive to start editing.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading && (
            <div className="flex justify-center items-center h-48">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          )}
          {!isLoading && !hasProducts && !isGoogleConnected && (
              <div className="text-center py-12">
                <Settings className="mx-auto h-12 w-12 text-muted-foreground" />
                <h3 className="mt-4 text-lg font-medium">Connect to Google Drive</h3>
                <p className="mt-1 text-sm text-muted-foreground max-w-md mx-auto">
                    To save and export your products, you need to connect your Google Drive account first.
                </p>
                <Button asChild className="mt-4">
                    <Link href="/dashboard/settings">
                    Go to Settings
                    </Link>
                </Button>
              </div>
          )}
          {!isLoading && !hasProducts && isGoogleConnected && (
             <div className="text-center py-12">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-medium">No Products Yet</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                You haven&apos;t generated any products.
              </p>
              <Button asChild className="mt-4">
                <Link href="/dashboard/product-charter">
                  Generate a New Product
                </Link>
              </Button>
            </div>
          )}
          {!isLoading && hasProducts && (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Date Created</TableHead>
                  <TableHead>
                    <span className="sr-only">Actions</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sortedProducts.map((product) => (
                  <ProductRow key={product.id} product={product} />
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
