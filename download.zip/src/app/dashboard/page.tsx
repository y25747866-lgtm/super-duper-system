'use client';

import { useMemo } from 'react';
import Link from 'next/link';
import { collection } from 'firebase/firestore';
import { useCollection, useFirebase, useMemoFirebase } from '@/firebase';
import type { DigitalProduct } from '@/lib/types';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Bot, FileText, Lightbulb, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Skeleton } from '@/components/ui/skeleton';

export default function DashboardPage() {
  const { firestore, user } = useFirebase();

  const productsCollection = useMemoFirebase(
    () => (firestore && user ? collection(firestore, 'users', user.uid, 'digitalProducts') : null),
    [firestore, user]
  );

  const { data: products, isLoading } = useCollection<DigitalProduct>(productsCollection);

  const sortedProducts = useMemo(() => {
    if (!products) return [];
    return [...products].sort((a, b) => {
      const dateA = a.createdAt ? new Date(a.createdAt).getTime() : 0;
      const dateB = b.createdAt ? new Date(b.createdAt).getTime() : 0;
      return dateB - dateA;
    });
  }, [products]);

  const recentProducts = sortedProducts.slice(0, 5);

  const kpiData = [
    {
      title: 'Products Generated',
      getValue: () => isLoading ? <Skeleton className="w-8 h-8" /> : products?.length ?? 0,
      icon: <Bot className="h-6 w-6 text-muted-foreground" />,
      change: 'from product generator',
    },
    {
      title: 'Assets Exported',
      value: '0',
      icon: <FileText className="h-6 w-6 text-muted-foreground" />,
      change: 'to Google Drive',
    },
    {
      title: 'Ideas Discovered',
      value: '0',
      icon: <Lightbulb className="h-6 w-6 text-muted-foreground" />,
      change: 'from UVZ & Trends',
    },
  ];

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold font-headline">Welcome, Boss</h1>
        <p className="text-muted-foreground">
          Here&apos;s the command center for your digital empire.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        {kpiData.map((kpi) => (
          <Card key={kpi.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{kpi.title}</CardTitle>
              {kpi.icon}
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{typeof kpi.getValue === 'function' ? kpi.getValue() : kpi.value}</div>
              <p className="text-xs text-muted-foreground">{kpi.change}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-headline">Recent Products</CardTitle>
          <CardDescription>
            A list of your recently generated digital products.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
             <div className="flex justify-center items-center h-48">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : recentProducts.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Product Name</TableHead>
                  <TableHead>Type</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>
                    <span className="sr-only">Actions</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {recentProducts.map((product) => (
                  <TableRow key={product.id}>
                    <TableCell className="font-medium">{product.title}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize">{product.productType}</Badge>
                    </TableCell>
                    <TableCell>
                      <Badge
                        variant="default"
                        className='bg-green-600/20 text-green-400 border-green-600/20'
                      >
                        Completed
                      </Badge>
                    </TableCell>
                    <TableCell>{new Date(product.createdAt).toLocaleDateString()}</TableCell>
                    <TableCell className="text-right">
                       <Button asChild variant="ghost" size="sm" disabled={!product.googleDriveFileId}>
                        <a
                          href={`https://docs.google.com/document/d/${product.googleDriveFileId}`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          View
                        </a>
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
             <div className="text-center py-12">
              <FileText className="mx-auto h-12 w-12 text-muted-foreground" />
              <h3 className="mt-4 text-lg font-medium">No Products Yet</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                You haven&apos;t generated any products.
              </p>
              <Button asChild className="mt-4">
                <Link href="/dashboard/product-charter">
                  Generate a New Product
                </Link>
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
