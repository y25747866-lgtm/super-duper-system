import { config } from 'dotenv';
config();

import '@/ai/flows/generate-uvz-product-ideas.ts';
import '@/ai/flows/discover-trending-digital-products.ts';
import '@/ai/flows/generate-charter-and-cover.ts';
