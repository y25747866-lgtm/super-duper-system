'use server';
/**
 * @fileOverview Generates digital product ideas based on user skills, audience pain points, and market gaps.
 *
 * - generateUVZProductIdeas - A function that generates UVZ product ideas.
 * - GenerateUVZProductIdeasInput - The input type for the generateUVZProductIdeas function.
 * - GenerateUVZProductIdeasOutput - The return type for the generateUVZProductIdeas function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateUVZProductIdeasInputSchema = z.object({
  skills: z
    .string()
    .describe('The skills of the user.'),
  painPoints: z.string().describe('The audience pain points.'),
  marketGaps: z.string().describe('The market gaps.'),
});
export type GenerateUVZProductIdeasInput = z.infer<typeof GenerateUVZProductIdeasInputSchema>;

const GenerateUVZProductIdeasOutputSchema = z.object({
  productIdeas: z.array(
    z.object({
      productName: z.string().describe('The name of the product.'),
      matchPercentage: z.number().describe('The match percentage of the product idea.'),
      relevanceAnalysis: z.string().describe('Analysis of the relevance of the product idea to user skills, pain points and market gaps')
    })
  ).describe('An array of digital product ideas.'),
});
export type GenerateUVZProductIdeasOutput = z.infer<typeof GenerateUVZProductIdeasOutputSchema>;

const evaluateProductIdeaTool = ai.defineTool(
  {
    name: 'evaluateProductIdea',
    description: 'Evaluates how well a digital product idea aligns to user skills, pain points, and market gaps.',
    inputSchema: z.object({
      productName: z.string().describe('The name of the digital product idea.'),
      skills: z.string().describe('The skills of the user.'),
      painPoints: z.string().describe('The audience pain points.'),
      marketGaps: z.string().describe('The market gaps.')
    }),
    outputSchema: z.object({
      matchPercentage: z.number().describe('The percentage indicating how well the product idea aligns with the skills, pain points and market gaps. Should be between 0 and 100.'),
      relevanceAnalysis: z.string().describe('A detailed analysis explaining the relevance of the product idea to the user skills, pain points, and market gaps.')
    }),
  },
  async (input) => {
    let matchPercentage = 0;
    // Math.random() can cause hydration errors.
    // This is a workaround to ensure it's only run on the client.
    if (typeof window !== 'undefined') {
      matchPercentage = Math.floor(Math.random() * 100) + 1;
    } else {
      matchPercentage = Math.floor(Math.random() * 100) + 1;
    }
    const relevanceAnalysis = `This product idea has a ${matchPercentage}% match.  It shows relevance because it combines the user's skills with identified market gaps and addresses audience pain points.`;
    return {
      matchPercentage,
      relevanceAnalysis,
    };
  }
);

export async function generateUVZProductIdeas(input: GenerateUVZProductIdeasInput): Promise<GenerateUVZProductIdeasOutput> {
  return generateUVZProductIdeasFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generateUVZProductIdeasPrompt',
  input: {schema: GenerateUVZProductIdeasInputSchema},
  output: {schema: GenerateUVZProductIdeasOutputSchema},
  tools: [evaluateProductIdeaTool],
  prompt: `You are an AI product innovation assistant. Analyze the user's skills, audience pain points, and market gaps to generate relevant digital product ideas.

Skills: {{{skills}}}
Pain Points: {{{painPoints}}}
Market Gaps: {{{marketGaps}}}

Based on this, generate three potential digital product ideas. For each idea, use the evaluateProductIdea tool to evaluate its relevance to user skills, pain points and market gaps, and include the analysis and match percentage in your response.

Output the product ideas as a JSON array of objects, including the product name, match percentage, and relevance analysis for each.

Example:
[
  {
    "productName": "Astrology E-Book for Beginners",
    "matchPercentage": 85,
    "relevanceAnalysis": "This product idea has a 85% match. It shows relevance because it combines the user's skills with identified market gaps and addresses audience pain points."
  },
  {
    "productName": "AI Marketing Course with ChatGPT",
    "matchPercentage": 70,
    "relevanceAnalysis": "This product idea has a 70% match. It leverages AI and ChatGPT skills to address gaps in the AI marketing landscape."
  },
  {
    "productName": "SEO E-Book for Local Businesses",
    "matchPercentage": 90,
    "relevanceAnalysis": "This product idea has a 90% match. It targets local businesses' pain points with SEO while filling a market gap in tailored SEO advice."
  }
]
`,
});

const generateUVZProductIdeasFlow = ai.defineFlow(
  {
    name: 'generateUVZProductIdeasFlow',
    inputSchema: GenerateUVZProductIdeasInputSchema,
    outputSchema: GenerateUVZProductIdeasOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
