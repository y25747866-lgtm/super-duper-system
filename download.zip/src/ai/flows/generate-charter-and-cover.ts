'use server';
/**
 * @fileOverview Generates a digital product charter and a cover image.
 *
 * - generateCharterAndCover - A function that generates the product charter and cover.
 * - GenerateCharterAndCoverInput - The input type for the function.
 * - GenerateCharterAndCoverOutput - The return type for the function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateCharterAndCoverInputSchema = z.object({
  productName: z.string().describe('The name of the product.'),
  productType: z
    .enum(['ebook', 'course'])
    .describe('The type of product (ebook or course).'),
});
export type GenerateCharterAndCoverInput = z.infer<
  typeof GenerateCharterAndCoverInputSchema
>;

const GenerateCharterAndCoverOutputSchema = z.object({
  charterContent: z
    .string()
    .describe('The generated product charter content in Markdown format.'),
  coverImageUrl: z
    .string()
    .optional()
    .describe('URL of the AI-generated cover image.'),
  altText: z.string().optional().describe('Alt text for the cover image.'),
});
export type GenerateCharterAndCoverOutput = z.infer<
  typeof GenerateCharterAndCoverOutputSchema
>;

export async function generateCharterAndCover(
  input: GenerateCharterAndCoverInput
): Promise<GenerateCharterAndCoverOutput> {
  return generateCharterAndCoverFlow(input);
}

// A single, robust prompt to generate the full charter content.
const charterContentPrompt = ai.definePrompt({
    name: 'generateFullCharterPrompt',
    input: { schema: GenerateCharterAndCoverInputSchema },
    prompt: `You are an expert content creator and instructional designer. Generate a complete and detailed product charter for a new {{productType}} titled "{{productName}}".

The output must be a single, complete document in well-structured Markdown format.

- The document should start with a main title: # {{productName}}.
- It must contain between 7 and 10 main sections, each starting with a level-2 heading (e.g., ## 1. Introduction).
- Each section must contain substantial, well-written content, including paragraphs, bullet points, and bold text for emphasis. Do not just write a short summary.
- If it's a **course**, the sections should be "Modules".
- If it's an **ebook**, the sections should be "Chapters".

Example structure for an ebook:
# The Art of Astrology
## 1. Introduction to the Zodiac
... detailed content ...
## 2. The Planets and Their Meanings
... detailed content ...
... and so on for 7-10 total chapters ...

Generate the full content now.
`,
});


const generateCharterAndCoverFlow = ai.defineFlow(
  {
    name: 'generateCharterAndCoverFlow',
    inputSchema: GenerateCharterAndCoverInputSchema,
    outputSchema: GenerateCharterAndCoverOutputSchema,
  },
  async (input: GenerateCharterAndCoverInput) => {
    // Step 1: Generate the full charter content in a single call
    const contentResponse = await charterContentPrompt(input);
    const fullCharterContent = contentResponse.text;

    if (!fullCharterContent) {
        throw new Error('Failed to generate product charter content.');
    }

    // Step 2: Generate the cover image (gracefully)
    let coverImageUrl: string | undefined;
    let altText: string | undefined;

    try {
      const imageResponse = await ai.generate({
        model: 'googleai/imagen-4.0-fast-generate-001',
        prompt: `minimalist book cover for '${input.productName}', professional, elegant, with space for text`,
      });
      coverImageUrl = imageResponse.media.url;
      altText = `AI-generated cover for ${input.productName}`;
    } catch (error) {
      console.warn(
        'Image generation failed, proceeding without a cover image:',
        error
      );
      // The flow will continue without an image
    }

    return { charterContent: fullCharterContent, coverImageUrl, altText };
  }
);
