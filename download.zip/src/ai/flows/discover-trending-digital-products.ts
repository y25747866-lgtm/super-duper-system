'use server';
/**
 * @fileOverview AI flow to discover trending digital product topics for 2025.
 *
 * - discoverTrendingProducts - A function that discovers trending digital products.
 * - DiscoverTrendingProductsInput - The input type for the discoverTrendingProducts function.
 * - DiscoverTrendingProductsOutput - The return type for the discoverTrendingProducts function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const DiscoverTrendingProductsInputSchema = z.object({
  query: z
    .string()
    .describe("A query describing the type of digital products to search for, e.g., 'AI marketing courses', 'SEO eBooks'."),
});
export type DiscoverTrendingProductsInput = z.infer<typeof DiscoverTrendingProductsInputSchema>;

const DiscoverTrendingProductsOutputSchema = z.object({
  products: z.array(
    z.object({
      title: z.string().describe('The title of the trending digital product.'),
      description: z.string().describe('A short description of the trending digital product.'),
      marketAnalysis: z.string().describe('An analysis of the market demand for this product in 2025.'),
    })
  ).describe('A list of trending digital products for 2025.'),
});
export type DiscoverTrendingProductsOutput = z.infer<typeof DiscoverTrendingProductsOutputSchema>;

export async function discoverTrendingProducts(input: DiscoverTrendingProductsInput): Promise<DiscoverTrendingProductsOutput> {
  return discoverTrendingProductsFlow(input);
}

const discoverTrendingProductsPrompt = ai.definePrompt({
  name: 'discoverTrendingProductsPrompt',
  input: {schema: DiscoverTrendingProductsInputSchema},
  output: {schema: DiscoverTrendingProductsOutputSchema},
  prompt: `You are an AI assistant specializing in identifying trending digital product topics for the year 2025.

  Based on the user's query, research and identify potential digital products that are expected to be in high demand in 2025.
  Provide a list of products, including a title, a brief description, and a market analysis indicating the demand and potential for each product.

  Query: {{{query}}}

  Format the output as a JSON array of objects, where each object has the following keys:
  - title (string): The title of the trending digital product.
  - description (string): A short description of the trending digital product.
  - marketAnalysis (string): An analysis of the market demand for this product in 2025.
  `,
});

const discoverTrendingProductsFlow = ai.defineFlow(
  {
    name: 'discoverTrendingProductsFlow',
    inputSchema: DiscoverTrendingProductsInputSchema,
    outputSchema: DiscoverTrendingProductsOutputSchema,
  },
  async input => {
    const {output} = await discoverTrendingProductsPrompt(input);
    return output!;
  }
);
