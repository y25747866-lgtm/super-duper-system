'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  CircleDollarSign,
  LayoutDashboard,
  Lightbulb,
  FileText,
  TrendingUp,
  FolderKanban,
  Settings,
} from 'lucide-react';

import { cn } from '@/lib/utils';
import {
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from '@/components/ui/sidebar';
import { Icons } from './icons';
import { Button } from './ui/button';

const menuItems = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { href: '/dashboard/uvz-calculator', label: 'UVZ Calculator', icon: Lightbulb },
  { href: '/dashboard/trends', label: 'Trends Search', icon: TrendingUp },
  { href: '/dashboard/product-charter', label: 'Product Charter', icon: FileText },
  { href: '/dashboard/my-products', label: 'My Products', icon: FolderKanban },
  { href: '/dashboard/monetization', label: 'Monetization', icon: CircleDollarSign },
  { href: '/dashboard/settings', label: 'Settings', icon: Settings },
];

export function DashboardNav() {
  const pathname = usePathname();

  return (
    <div className="flex flex-col h-full">
      <div className="p-4">
        <Button
            variant="ghost"
            className="flex items-center gap-2 w-full justify-start"
            asChild
        >
            <Link href="/">
                <Icons.logo className="h-8 w-8" />
                <span className="font-bold text-lg font-headline">Boss OS</span>
            </Link>
        </Button>
      </div>

      <SidebarMenu className="flex-1 p-4">
        {menuItems.map(({ href, label, icon: Icon }) => (
          <SidebarMenuItem key={href}>
            <SidebarMenuButton
              asChild
              className={cn(
                'justify-start',
                pathname === href &&
                  'bg-primary/10 text-primary hover:bg-primary/20 hover:text-primary'
              )}
            >
              <Link href={href} className="flex items-center gap-3">
                <Icon className="h-5 w-5" />
                <span>{label}</span>
              </Link>
            </SidebarMenuButton>
          </SidebarMenuItem>
        ))}
      </SidebarMenu>
    </div>
  );
}
