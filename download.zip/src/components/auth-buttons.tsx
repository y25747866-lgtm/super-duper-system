'use client';

import {
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  type User as FirebaseUser,
} from 'firebase/auth';
import { useAuth, useUser } from '@/firebase';
import { Button, buttonVariants } from '@/components/ui/button';
import { Icons } from '@/components/icons';
import { Loader2, LogOut } from 'lucide-react';
import Link from 'next/link';
import { cn } from '@/lib/utils';
import { createUserAction } from '@/lib/actions/user';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

export function AuthButtons({ largeButton = false }: { largeButton?: boolean }) {
  const { user, isUserLoading } = useUser();
  const auth = useAuth();
  const { toast } = useToast();
  const router = useRouter();

  const handleSignIn = async () => {
    if (!auth) {
      toast({
        variant: 'destructive',
        title: 'Sign In Failed',
        description: 'Authentication service is not available. Please try again later.',
      });
      return;
    }
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      // The user object from the result contains all the necessary info.
      if (result.user) {
        await createUserAction({
          uid: result.user.uid,
          email: result.user.email,
          displayName: result.user.displayName,
          photoURL: result.user.photoURL,
        });
      }
      toast({
        title: 'Signed In!',
        description: 'Welcome back!',
      });
      router.push('/dashboard');
    } catch (error: any) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Sign In Failed',
        description: error.message || 'Could not sign in with Google. Please try again.',
      });
    }
  };

  const handleSignOut = async () => {
    if (!auth) {
      toast({
        variant: 'destructive',
        title: 'Sign Out Failed',
        description: 'Authentication service is not available.',
      });
      return;
    }
    try {
      await signOut(auth);
      toast({
        title: 'Signed Out',
        description: 'You have been successfully signed out.',
      });
      router.push('/');
    } catch (error: any) {
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Sign Out Failed',
        description: error.message || 'Could not sign out. Please try again.',
      });
    }
  };

  if (isUserLoading) {
    return (
      <div className="space-x-4">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  if (user) {
    return (
      <div className="flex items-center gap-4">
        <Button asChild size={largeButton ? 'lg' : 'sm'}>
          <Link href="/dashboard">Go to Dashboard</Link>
        </Button>
        <Button variant="ghost" size="sm" onClick={handleSignOut}>
          <LogOut className="mr-2" />
          Sign Out
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-4">
      <Link href="/dashboard" className={cn(buttonVariants({ size: largeButton ? 'lg' : 'default', variant: 'outline' }), largeButton ? '' : 'hidden sm:inline-flex')}>
        Get Started Now
      </Link>
      <Button onClick={handleSignIn} size={largeButton ? 'lg' : 'sm'}>
        <Icons.google className="mr-2" /> Sign in with Google
      </Button>
    </div>
  );
}
