import type { SVGProps } from 'react';

export const Icons = {
  logo: (props: SVGProps<SVGSVGElement>) => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 512 512"
      role="img"
      aria-labelledby="title desc"
      {...props}
    >
      <title id="title">Boss OS Neural Circuit Logo</title>
      <desc id="desc">
        Stylized brain-shaped circuit logo with blue-to-green gradient
      </desc>

      <defs>
        <linearGradient id="grad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#00C6FF" />
          <stop offset="100%" stopColor="#00FF88" />
        </linearGradient>
      </defs>

      <path
        fill="none"
        stroke="url(#grad)"
        strokeWidth="32"
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M160 160 
           L240 160 Q320 160 320 240
           L320 272 M320 272 
           Q320 352 400 352
           L416 352
           M320 240 
           L400 160
           M160 240 
           Q160 320 240 320 
           L272 320
           M160 160 
           Q160 120 200 120 
           L240 120
           M160 240 
           L120 200
           M272 320 
           L240 360
           M400 352 
           L440 400
           M320 272 
           L360 312
           M240 160 
           L200 200
           M240 120 
           L272 80
           M160 240 
           L120 280
           M240 320 
           L200 360
           M272 320 
           L312 360
           M200 200 
           L240 240
           M360 312 
           L400 352"
      />

      <circle cx="200" cy="120" r="16" fill="url(#grad)" />
      <circle cx="272" cy="80" r="16" fill="url(#grad)" />
      <circle cx="120" cy="200" r="16" fill="url(#grad)" />
      <circle cx="120" cy="280" r="16" fill="url(#grad)" />
      <circle cx="200" cy="360" r="16" fill="url(#grad)" />
      <circle cx="312" cy="360" r="16" fill="url(#grad)" />
      <circle cx="440" cy="400" r="16" fill="url(#grad)" />
    </svg>
  ),
  google: (props: SVGProps<SVGSVGElement>) => (
    <svg
      role="img"
      viewBox="0 0 24 24"
      xmlns="http://www.w3.org/2000/svg"
      {...props}
    >
      <title>Google</title>
      <path
        fill="currentColor"
        d="M12.48 10.92v3.28h7.84c-.24 1.84-.85 3.18-1.73 4.1-1.05 1.05-2.86 2.25-5.02 2.25-4.33 0-7.87-3.55-7.87-7.95s3.54-7.95 7.87-7.95c2.23 0 3.98.89 5.25 2.19l2.75-2.75c-1.7-1.6-3.95-2.6-6.9-2.6-5.73 0-10.4 4.67-10.4 10.4s4.67 10.4 10.4 10.4c3.35 0 5.92-1.12 7.85-3.03 2-1.97 2.58-4.7 2.58-7.15 0-.65-.07-1.3-.18-1.92H12.48z"
      />
    </svg>
  ),
};
